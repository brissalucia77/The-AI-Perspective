# The AI Perspective

A React + Vite survey and public-results dashboard.

## Pages
- `/` — public survey form
- `/dashboard` — dashboard reading the `public_response_records` table

## 1. Supabase environment variables

Create a `.env.local` file in the project root (do not commit it) using `.env.example`:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

Use the Supabase **Project URL** and **publishable** key. Never use a `service_role` or secret key in browser code.

## 2. Install and run

```bash
npm install
npm run dev
```

## 3. Build check

```bash
npm run build
```

## 4. Database assumptions

The survey inserts into `public.survey_responses` with these columns:
`submission_id`, `survey_version`, `alias`, `age`, `gender`, `school_grade`, `main_interest`, `ai_knowledge`, `ai_usage_frequency`, `ai_opinion`, `employment_impact`, `opportunities_risks`.

The dashboard reads only:
`display_key`, `age_band`, `school_grade`, `main_interest`, `ai_knowledge`, `ai_usage_frequency`, `ai_opinion`, `employment_impact`, `opportunities_risks`
from `public.public_response_records`.

This app does **not** insert into `public_response_records`. Before launch, verify that your database has a trusted trigger/function or other server-side process that populates this public reporting table from survey submissions and applies its privacy threshold. A table and SELECT policy alone do not populate it.

## 5. GitHub

Create a repository named `the-ai-perspective`, then upload the contents of this folder to the repository root. Do not upload `.env.local`.

## 6. Vercel

Import the GitHub repository. Vercel should detect Vite. Add the two environment variables in Project Settings → Environment Variables, then redeploy. The included `vercel.json` supports the `/dashboard` route.

## Privacy note

The survey asks for an alias, not a full name. The dashboard never queries `survey_responses`; it reads only the public reporting table. Review your RLS policies and database-side aggregation logic before collecting real responses.
